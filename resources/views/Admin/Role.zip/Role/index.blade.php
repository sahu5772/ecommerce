@extends('layouts/ecommerce')
@section('content')
     
    

 
   

      <section class="home-section">
    <nav class="n_user">
    <div class="profile-details">
      <i class='bx bx-cart' ></i>
        <a href="{{route('role.create')}}" class="new-user">Add Role</a>
      </div>
      @if(Session::has('success'))
        <div class="success"> {{Session::get('success')}}</div>
        @endif
        @if(Session::has('error'))
        <div class="error"> {{Session::get('error')}}</div>
        @endif
    </nav>

    <div class="home-content">
     
          
      </div>
    </div>
  </section>

<section class="home-sec">

    <table class="user_table">
    <tr>
        <th>Id</th>
        <th>name</th>
        <th>guard_name</th>
        <th>permission</th>
        <th>Action</th>
    </tr>
        @foreach($roleData as $_role)
            <tr>
                <td>{{$_role->id}}</td>
                <td>{{$_role->name}}</td>
                <td>{{$_role->guard_name}}</td>
                <td>{{$_role->permission}}</td>
                <td>
                <form method="post" action="{{route('role.destroy',$_role->id)}}">
            <a class="edit-data" href="{{route('role.edit',$_role->id)}}">Edit</a>
                                @method('DELETE')
                                @csrf
                                    <button  onclick="return confirm('Are you sure?')" class="delete-data">Delete</button>
                                    </form>
                                </td>
                </td>
            </tr>
            @endforeach

   
    </table>
</section>  


@endsection