<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{ asset('css/ecommerce.css') }}">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="{{ asset('css/user_index.css') }}">
   </head>
   <style>

   </style>
<body>
@include('includes/admin.navigation')
      <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Manage Permission</span>
      </div>
      <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search' ></i>
      </div>
      <div class="profile-details">
        <span class="admin_name">Mahendra sahu</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <div class="home-content">
     
          
      </div>
    </div>
  </section>
      <section class="home-section">
    <nav class="n_user">
    <div class="profile-details">
      <i class='bx bx-cart' ></i>
        <a href="{{route('permission.create')}}" class="new-user">Add Permission</a>
      </div>
      @if(Session::has('success'))
        <div class="success"> {{Session::get('success')}}</div>
        @endif
        @if(Session::has('error'))
        <div class="error"> {{Session::get('error')}}</div>
        @endif
    </nav>

    <div class="home-content">
     
          
      </div>
    </div>
  </section>

<section class="home-sec">

    <table class="user_table">
    <tr>
        <th>Id</th>
        <th>name</th>
        <th>guard_name</th>
        <th>Action</th>
    </tr>

        @foreach($perData as $_permission)
        <tr>
            <td>{{$_permission->id}}</td>
            <td>{{$_permission->name}}</td>
            <td>{{$_permission->guard_name}}</td>
            <td>
            <form method="post" action="{{route('permission.destroy',$_permission->id)}}">
        <a class="edit-data" href="{{route('permission.edit',$_permission->id)}}">Edit</a>
                            @method('DELETE')
                            @csrf
                                <button  onclick="return confirm('Are you sure?')" class="delete-data">Delete</button>
                                </form>
                            </td>
            </td>
        </tr>
        @endforeach

    </table>

</section>


</body>

</html>

